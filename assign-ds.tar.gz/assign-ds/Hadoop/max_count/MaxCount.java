import java.io.IOException;
   import java.util.*;
        
   import org.apache.hadoop.fs.Path;
   import org.apache.hadoop.conf.*;
   import org.apache.hadoop.io.*;
   import org.apache.hadoop.mapreduce.*;
   import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
   import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
   import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
   import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
           
   public class MaxCount {
           
    public static class Map extends Mapper<LongWritable, Text, Text, IntWritable> {
       private final static IntWritable one = new IntWritable(1);
       private Text word = new Text();
           
       public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
           String line = value.toString();
           String space[]=line.split(" ");
           
           for(int j=0;j<space.length;j++)
           {
        	  String comma[]=space[j].split(",");
               word.set(comma[0]+"#"+comma[1]+"#");
        	    context.write(word, one);
           
           }
       }
    } 
           
    public static class Reduce extends Reducer<Text, IntWritable, Text, IntWritable> {
   
       public void reduce(Text key, Iterable<IntWritable> values, Context context) 
         throws IOException, InterruptedException {
    	   int n1,n2;
    	   int max = 0;
           String ip[]=key.toString().split("#");
           for(int i=0,j=1;i<ip.length && j<ip.length;i++,j++)
           {
              n1=Integer.parseInt(ip[i]);
              n2=Integer.parseInt(ip[j]);
              if(n1>n2)
            	  max=n1;
              else
            	  max=n2;
              i++;j++;
           }
           String line=key.toString();
           	line=line.replace("#", " ");
           context.write(new Text(line), new IntWritable(max));
       }
    }
           
    public static void main(String[] args) throws Exception {
       Configuration conf = new Configuration();
           
           Job job = new Job(conf, "wordcount");
       
       job.setOutputKeyClass(Text.class);
       job.setOutputValueClass(IntWritable.class);
           
       job.setMapperClass(Map.class);
       job.setReducerClass(Reduce.class);
           
       job.setInputFormatClass(TextInputFormat.class);
       job.setOutputFormatClass(TextOutputFormat.class);
           
       FileInputFormat.addInputPath(job, new Path(args[0]));
       FileOutputFormat.setOutputPath(job, new Path(args[1]));
          
       job.waitForCompletion(true);
    }
           
  }