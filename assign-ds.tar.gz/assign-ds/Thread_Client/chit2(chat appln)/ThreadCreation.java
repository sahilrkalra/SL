import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.io.BufferedReader;
import java.io.InputStreamReader;
public class ThreadCreation implements Runnable {
 
	Socket socket;
	
	ThreadCreation(Socket socket)
	{
	    this.socket=socket;
	}

	@Override
	public void run() {
	
		
		try {
			DataInputStream din=new DataInputStream(socket.getInputStream());
			DataOutputStream dout=new DataOutputStream(socket.getOutputStream());
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			String in=" ",out="",name="";
			dout.flush();
			name=din.readUTF();
			while(!out.equals("Stop"))
			{
				
				out=din.readUTF();
				System.out.println(name+":"+out);
				System.out.println("Enter reply:");
				out=br.readLine();
				dout.writeUTF(out);
			}
			din.close();
			dout.close();
			socket.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	
	
}
