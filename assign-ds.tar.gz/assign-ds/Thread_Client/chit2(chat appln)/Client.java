import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;


public class Client {

	public static void main(String[] args) {
		try {
			Socket socket=new Socket("",1234);
			DataInputStream din=new DataInputStream(socket.getInputStream());
			DataOutputStream dout=new DataOutputStream(socket.getOutputStream());
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			String in="",out="",name="";
			System.out.println("Enter ur name:");
			name=br.readLine();
			dout.writeUTF(name);
			System.out.println("Enter message:");
			while(!in.equals("Stop"))
			{
				out=br.readLine();
				dout.flush();
				dout.writeUTF(out);
				in=din.readUTF();
				System.out.println("Server says:"+in);
				
			}
			socket.close();
			
			
			
			
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
