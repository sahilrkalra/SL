//package Addition;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class ThreadCreate implements Runnable{

	Socket socket;
	ThreadCreate(Socket socket)
	{
		this.socket=socket;
	}
	
	double degree_to_radian(String n)
	{	
		
		int no2=Integer.parseInt(n);
		//System.out.println("no2:"+no2);
		double res=1.0;
		res=no2*0.0174533;
		return res;
	}
	
	@Override
	public void run() {
		try {
			DataInputStream din=new DataInputStream(socket.getInputStream());
			DataOutputStream dout=new DataOutputStream(socket.getOutputStream());
			String str1="",str2="",name="";
			//name=din.readUTF();
			while(!str1.equals("Stop"))
			{
				str1=din.readUTF();
				System.out.println("Client"+name+" send no:"+str1);
				double ans=degree_to_radian(str1);
				dout.writeUTF("meter of "+str1+"="+String.valueOf(ans));
			}
			din.close();
			dout.close();
			socket.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
	
	
	
}
