//package Addition;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	static ServerSocket server=null;
	public static void main(String[] args) {
		System.out.println("Server is running.................");
		Runnable rr=new Runnable()
		{

			@Override
			public void run() {
				try {
					int i=1;
					server=new ServerSocket(2341);
					while(true)
					{
						Socket socket=server.accept();
						if(socket!=null)
						{
							System.out.println("Creating thread "+i);
							i++;
							new Thread(new ThreadCreate(socket)).start();
						}
						else
							break;
					}
					server.close();
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			
		};
		new Thread(rr).start();
	}

}
