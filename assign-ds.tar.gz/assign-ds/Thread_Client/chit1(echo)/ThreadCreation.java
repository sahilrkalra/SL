import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;


public class ThreadCreation implements Runnable {
 
	Socket socket;
	
	ThreadCreation(Socket socket)
	{
	    this.socket=socket;
	}

	@Override
	public void run() {
	
		
		try {
			DataInputStream din=new DataInputStream(socket.getInputStream());
			DataOutputStream dout=new DataOutputStream(socket.getOutputStream());
			String in=" ",out="";
			dout.flush();
			while(!out.equals("Stop"))
			{
				
				out=din.readUTF();
				System.out.println("Client says:"+out);
				dout.writeUTF(out);
			}
			din.close();
			dout.close();
			socket.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	
	
}
