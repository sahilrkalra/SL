//package Addition;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class ThreadCreate implements Runnable{

	Socket socket;
	ThreadCreate(Socket socket)
	{
		this.socket=socket;
	}
	
	int add(String n)
	{	
		int no=Integer.parseInt(n);
		int res=0;
		while(no>0)
		{
			res+=no%10;
			no=no/10;
		}
	
		return res;
	}
	
	@Override
	public void run() {
		try {
			DataInputStream din=new DataInputStream(socket.getInputStream());
			DataOutputStream dout=new DataOutputStream(socket.getOutputStream());
			String str1="",str2="",name="";
			name=din.readUTF();
			while(!str1.equals("Stop"))
			{
				str1=din.readUTF();
				System.out.println("Client"+name+" send no:"+str1);
				int ans=add(str1);
				dout.writeUTF("Addition of "+str1+"="+String.valueOf(ans));
			}
			din.close();
			dout.close();
			socket.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
	
	
	
}
