
import java.rmi.server.UnicastRemoteObject;
import java.rmi.*;

public class ConcatRemote extends UnicastRemoteObject implements Concater
{
	protected ConcatRemote() throws RemoteException
	{
		super();
	}
	

	@Override
	public String StrReverseCheck(String s1, String s2) throws RemoteException 
	{
		String res = "";
		String snew = s1;
		  for ( int i = s1.length() - 1 ; i >= 0 ; i-- )
		         res = res + s1.charAt(i);
		 
		  if(s2.equals(res))
		  {
			  res = "Reverse of "+res+" is equals to "+s2;
			  return res;
		  }
		  else
		  {
			  res = "Reverse of "+res+" is NOT equals to "+s2;
			  return res;
		  }
	}	
}
