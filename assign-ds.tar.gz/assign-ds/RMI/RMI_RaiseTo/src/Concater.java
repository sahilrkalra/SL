
import java.rmi.*;

public interface Concater extends Remote
{
	public int RaiseTo(int s1, int s2) throws RemoteException;
}
