import java.rmi.*;
import java.io.*;

public class MyClient 
{
	public static void main(String args[])
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		try
		{
			Concater stub = (Concater) Naming.lookup("rmi://127.0.0.1:5006/Concater");
			int s1,s2;
			System.out.println(" Enter first Number : " );
			s1 = Integer.parseInt(br.readLine());
			System.out.println(" Enter second Number : " );
			s2 = Integer.parseInt(br.readLine());
			
			System.out.println(" Output : "+stub.RaiseTo(s1, s2));
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
