
import java.rmi.server.UnicastRemoteObject;
import java.rmi.*;

public class ConcatRemote extends UnicastRemoteObject implements Concater
{
	protected ConcatRemote() throws RemoteException
	{
		super();
	}
	

	@Override
	public int RaiseTo(int s1,int s2) throws RemoteException 
	{
		int res = 1;
		for(int i=1;i<=s2;i++)
			res*=s1;
		return res;
			    
	}	
}
