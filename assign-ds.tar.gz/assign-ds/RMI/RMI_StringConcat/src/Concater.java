
import java.rmi.*;

public interface Concater extends Remote
{
	public String StrConcat(String s1, String s2) throws RemoteException;
}
