
import java.rmi.server.UnicastRemoteObject;
import java.rmi.*;

public class ConcatRemote extends UnicastRemoteObject implements Concater
{
	protected ConcatRemote() throws RemoteException
	{
		super();
	}
	

	@Override
	public String StrSubstring(String s1, String s2) throws RemoteException 
	{
		int i;
		String res=null;
		
		for(i=0;i<s2.length();i++)
		{
			if(s1.contains(s2))
			{
				res = s2+" is a substring of "+s1;
				return res;
			}
			else
			{
				res = s2+" is a NOT a substring of "+s1;
				return res;
				
			}
	
		}
		return res;
	}	
}
