import java.rmi.*;
import java.io.*;

public class MyClient 
{
	public static void main(String args[])
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		try
		{
			Concater stub = (Concater) Naming.lookup("rmi://127.0.0.1:5002/Concater");
			String s1,s2;
			System.out.println(" Enter first String : " );
			s1 = br.readLine();
			System.out.println(" Enter second String : " );
			s2 = br.readLine();
			
			System.out.println(" Output : "+stub.StrSubstring(s1, s2));
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
