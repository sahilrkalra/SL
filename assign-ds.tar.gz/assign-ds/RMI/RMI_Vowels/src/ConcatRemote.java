
import java.rmi.server.UnicastRemoteObject;
import java.rmi.*;

public class ConcatRemote extends UnicastRemoteObject implements Concater
{
	protected ConcatRemote() throws RemoteException
	{
		super();
	}
	

	@Override
	public String StrVowelsCount(String s1, String s2) throws RemoteException 
	{
		
		char ch;
		int cnt1 = 0,cnt2 = 0;
		for(int i=0;i<s1.length();i++)
		{
			ch = s1.charAt(i);
			if(ch =='a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')
				cnt1++;
		}
		
		for(int i=0;i<s2.length();i++)
		{
			ch = s2.charAt(i);
			if(ch =='a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')
				cnt2++;
		}
		
		if(cnt1 == cnt2)
		{
			return s1+" and "+s2+" contains same number of Vowels.";
		}
		else
		{
			return s1+" and "+s2+" DO NOT contains of same number of Vowels.";		
		}

	}	
}
