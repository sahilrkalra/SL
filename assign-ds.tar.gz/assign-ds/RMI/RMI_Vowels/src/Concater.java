
import java.rmi.*;

public interface Concater extends Remote
{
	public String StrVowelsCount(String s1, String s2) throws RemoteException;
}
