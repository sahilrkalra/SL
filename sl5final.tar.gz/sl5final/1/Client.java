import java.io.*;
import java.net.*;
import java.util.*;

public class Client {
    public static void main(String[] args) throws Exception{
        
        Socket s = new Socket("localhost", 3452);
        Random rand = new Random();
        Integer client_id = rand.nextInt(100);
        
        DataInputStream din = new DataInputStream(s.getInputStream());
        DataOutputStream dout = new DataOutputStream(s.getOutputStream());
        Scanner scan = new Scanner(System.in);
        
        String msg = "", rep = "";
        dout.flush();
        dout.writeUTF(client_id.toString());
        dout.flush();
        
        while(!msg.equals("stop"))
        {
            System.out.println("\nMessage to Server: ");
            msg = scan.nextLine();
            dout.writeUTF(msg);
            
            dout.flush();
            rep = din.readUTF();
            System.out.println("I said : " + rep);
        }
        
        din.close();
        dout.close();
        s.close();

        scan.close();
    }
}
