import java.io.*;
import java.net.*;
    
    public class ClientThread implements Runnable {
        private Socket s;
        
        public ClientThread(Socket _s) {
            this.s = _s;
        }
        
        @Override
        public void run() {
            // TODO Auto-generated method stub
            try {
                DataInputStream din = new DataInputStream(s.getInputStream());
                DataOutputStream dout = new DataOutputStream(s.getOutputStream());
                
                String incoming = "";
                String client_id = din.readUTF();
                
                System.out.println("Client " + client_id + " connected");
                
                while (!incoming.equals("stop")) {
                    incoming = din.readUTF();
                    System.out.println("\nClient " + client_id +" says: " + incoming);
                    
                    dout.writeUTF(incoming);
                    dout.flush();
                }
            
                din.close();
                dout.close();
                s.close();
            } catch (IOException e) {System.out.print(e);}
        }
    }
