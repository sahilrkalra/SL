#include "fact.h"
int *fact_1_svc(intpair *argp, struct svc_req *rqstp)
{
static int result,n,val;

n=argp->a;

printf("\n Received : n= %d \n",n);

    val=n*12;
 
result=val;	
return &result;
}
