import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.ResultSet;
import java.lang.*;
import java.io.*;
import java.util.*;

interface DBInterface extends Remote
{
public String input(String name1,String name2) throws RemoteException;
}
public class Server extends UnicastRemoteObject implements DBInterface
{
int flag=0,n,i,j;
String name3;
ResultSet r;
public Server() throws RemoteException
{ try
 { System.out.println("Initializing Server\nServer Ready");
 }
 catch (Exception e)
 { System.out.println("ERROR: " +e.getMessage());
 }
 }
public static void main(String[] args)
{ try
 {
 Server rs=new Server();
 java.rmi.registry.LocateRegistry.createRegistry(1030).rebind("DBServ",rs);

 }
catch (Exception e)
{
 System.out.println("ERROR: " +e.getMessage());
}
}
public String input(String name1,String name2)
{
 try{
    StringBuilder n3 = new StringBuilder();
    n3.append(name2);
    n3=n3.reverse();  
    System.out.println("Reverse is "+n3);
   
    if(name1.equals(n3.toString()))
    {   
        System.out.println("\nString is reverse");
        return "Palindorme";
    }
    else
    {
        System.out.println("\nString is not reverse");
        return "Not palindrome";
    }
 }
 catch (Exception e)
 {
 System.out.println("ERROR: " +e.getMessage());
 }
 return name3;
 }
}
